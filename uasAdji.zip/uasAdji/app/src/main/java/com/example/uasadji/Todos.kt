package com.example.uasadji

data class Todos(
    var userId: Int,
    var id: Int,
    var title: String,
    var completed: Boolean
)
