package com.example.uasadji

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var rvTodos: RecyclerView
    private val list = ArrayList<Todos>()
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvTodos = findViewById(R.id.rv_todos)
        rvTodos.setHasFixedSize(true)

        getListTodos("https://jsonplaceholder.typicode.com/todos")
    }

    private fun getListTodos(url: String) {
        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                val strResponse = response.body()?.string()

                try {
                    val jsonArray = JSONArray(strResponse)

                    for (i in 0 until jsonArray.length()) {
                        val jsonObject = jsonArray.getJSONObject(i)

                        val todo = Todos(
                            userId = jsonObject.getInt("userId"),
                            id = jsonObject.getInt("id"),
                            title = jsonObject.getString("title"),
                            completed = jsonObject.getBoolean("completed")
                        )

                        list.add(todo)
                    }

                    runOnUiThread {
                        setupRv()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        })
    }

    private fun setupRv() {
        rvTodos.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        val listTodoAdapter = ListBookAdapter(this, list)
        rvTodos.adapter = listTodoAdapter
    }
}

