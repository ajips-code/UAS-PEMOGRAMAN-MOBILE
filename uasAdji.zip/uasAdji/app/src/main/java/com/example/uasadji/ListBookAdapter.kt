package com.example.uasadji

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class ListBookAdapter(private val context: Context, private val listTodos: ArrayList<Todos>) :
    RecyclerView.Adapter<ListBookAdapter.ListViewHolder>() {

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvTitle: TextView = itemView.findViewById(R.id.tv_item_title)
        var tvUserId: TextView = itemView.findViewById(R.id.tv_item_userid)
        var tvCompleted: TextView = itemView.findViewById(R.id.iv_item_completed)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row_json, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val currentItem = listTodos[position]

        holder.tvTitle.text = listTodos[position].title
        holder.tvUserId.text = "User ID: ${listTodos[position].userId}"
        holder.tvCompleted.text =
            if (listTodos[position].completed) "True" else "False"

        // Set a click listener to show the notification
        holder.itemView.setOnClickListener {
            showNotification(currentItem.id, currentItem.title)
        }
    }

    override fun getItemCount(): Int = listTodos.size

    private fun showNotification(notificationId: Int, title: String) {
        createNotificationChannel()

        val builder = NotificationCompat.Builder(context, "your_channel_id")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Notification ID: $notificationId")
            .setContentText("Selected Title: $title")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(context)) {
            notify(notificationId, builder.build())
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Channel Name"
            val descriptionText = "Channel Description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel("your_channel_id", name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
